insert into test (CENTERID,TESTID,TESTNAME) values ('1','1','MRI');

insert into test (CENTERID,TESTID,TESTNAME) values ('3','2','CT SCAN');

commit;