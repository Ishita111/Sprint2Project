package com.sunsoft.Test.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.sunsoft.Test.entity.Test;
import com.sunsoft.Test.repository.TestRepository;

@Component
public class TestDAO implements  ITestDAO{

	@Autowired
    private TestRepository repository;

	@Override
	public List<Test> getAllTests() {
		return repository.findAll();
	}
	@Override
	public List<Test> getTest(String id){
		return repository.getTestById(id);		
	}
	@Override
	public int deleteTest(String id){
		return repository.deleteTestById(id);		
	}
	@Override
	public Test addTest(Test test) {
		return repository.save(test);
	}
	@Override
	public List<Test> getAllData() {
		return repository.findAll();
	}
}