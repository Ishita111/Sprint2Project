package com.sunsoft.Test.service;

import java.util.List;

import com.sunsoft.Test.entity.Test;

public interface ITestService{

	List<Test> getAllTest();

	List<Test> getTests(String id);

	public int deleteTests(String id);

	public Test addTests(Test test);

	List<Test> getAll();

}